## 1. 비정형 데이터 읽고 쓰기
# 한 줄 단위로 4줄만 읽어오기
txtLine4 <- readLines("트럼프국회연설문.txt", n = 4)
print(txtLine4)
# 읽어온 4줄을 파일에 저장하기
writeLines(txtLine4, "트럼프국회연설문-cp.txt")



## 2. csv파일 
kbo <- read.csv("kbo_sub.csv")
head(kbo)

write.csv(kbo, "kbo_cp.csv", row.names = FALSE, quote = TRUE )



##3. xlsx파일 
install.packages("xlsx")
library(xlsx)
data <- read.xlsx("연령별_실업률_2007_2016년.xlsx",sheetName="1", header = TRUE)
head(data, 5)
write.xlsx(data , "data_cp.xlsx", row.names = FALSE)
