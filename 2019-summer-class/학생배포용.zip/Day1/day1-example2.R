﻿install.packages("dplyr")           #패키지 설치
library(dplyr)                         #메모리 로드

score <- read.csv("score.csv")               
str(score )
head(score)


