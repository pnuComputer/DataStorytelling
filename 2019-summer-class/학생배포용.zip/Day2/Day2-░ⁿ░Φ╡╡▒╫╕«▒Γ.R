﻿##########################################################################3
# "igraph" 패키지 설치 및 불러오기 
install.packages( "igraph" ) 
library( igraph )

# [단계 1] 데이터파일 불러오기
data <- read.csv("관계도-회사.csv")
print(data)
#[단계 2] 관계도를 그리기 위한 데이터 편집하기
employee <- data.frame(data$성명, data$상사)	# 직원정보와 상사정보 데이터프레임 생성
print(employee)
# [단계 3] 그래프 형식으로 데이터 변환하기
g <- graph.data.frame(employee, directed = TRUE)
print(g) 
# [단계 4] 회사 관계도 그리기
plot(g, layout = layout.random, vertex.size = 5, edge.arrow.size = 0.3) 

##########################################################################3
#[단계1] 관계도-역학조사 데이터파일 불러오기
#

#[단계 2] 환자명 -  접촉자 관계도를 그리기 위한 데이터 편집하기


#[단계 3] 그래프 형식으로 데이터 변환하기


# [단계 4] 회사 관계도 그리기







