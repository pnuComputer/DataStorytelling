﻿## 우리나라 행정구역도 그리기  kormaps2014, moonBook2 이용
install.packages("devtools")
devtools::install_github("cardiomoon/kormaps2014")
devtools::install_github("cardiomoon/moonBook2")
library(kormaps2014)
library(moonBook2)
str(kormap1)
areacode1=changeCode(areacode)
areacode1

library(ggplot2)
#ggplot2를 이용한 단계구분도를 그려보자
#2015년 인구총조사 중 “총인구_명”으로 단계구분도를 그리기

theme_set(theme_gray(base_family="NanumGothic"))

ggplot(korpop1,
       aes(map_id=code,fill=총인구_명))+
        geom_map(map=kormap1,colour="black",size=0.1)+
        expand_limits(x=kormap1$long,y=kormap1$lat)+
        scale_fill_gradientn(colours=c('white','orange','red') )+
  ggtitle("2015년도 시도별 인구분포도")+
  coord_map()



#ggChoropleth()함수를 이용한 단계구분도 그리기
#동별 
ggChoropleth(korpop3,kormap3,fillvar="남자_명")
#1. 시도별 총인구_명 단계구분도 그려보자  
#

#2. 구군별 총인구_명 단계구분도 그려보자
#
