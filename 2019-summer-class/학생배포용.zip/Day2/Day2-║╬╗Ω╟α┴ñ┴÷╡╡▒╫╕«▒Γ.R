﻿####################################################
######       우리나라 행정구역도 그리기       ######
####################################################
install.packages("devtools")
devtools::install_github("cardiomoon/kormaps2014")
devtools::install_github("cardiomoon/moonBook2")
library(kormaps2014)
library(moonBook2)
str(kormap1)
areacode1=changeCode(areacode)
areacode1

##부산지도 행정지도2, 3 추출하기
##부산만 그리고 싶을때 사용 
pusmap2 <- kormap2 %>% mutate(subid = substr(sigungu_cd, 1,2)) %>%filter(subid == '21')
pusmap3 <- kormap3 %>% mutate(subid = substr(adm_dr_cd, 1,2)) %>%filter(subid == '21')

## ggChoropleth(데이터프레임, 행정지도, 그림필드명)
ggChoropleth(korpop3,pusmap3,fillvar="총인구_명") +
  ggtitle("2015년도 부산시 동별 인구분포도")
ggChoropleth(korpop2,pusmap2,fillvar="총인구_명")  +
  ggtitle("2015년도 부산시 구별 인구분포도")

ggplot(korpop2,
aes(map_id=code,fill=총인구_명))+
geom_map(map=pusmap2,colour="black",size=0.1)+
expand_limits(x=pusmap2$long,y=pusmap2$lat)+
scale_fill_gradientn(colours=c('white','orange','red') )+
ggtitle("2015년도 시도별 인구분포도")+
coord_map()

### 부산시 공공데이터에서 가져온 쓰레기 발생량 2017년 파일
data1 <- read.csv("부산광역시_쓰레기발생량_2017년도말기준.csv")
head(data1)
### 부산시 법정코드 파일 읽기
code1 <- read.csv("busanmap2_code.csv")
head(code1)
### 두데이터 합하기 
merge(data1, code1 , by="name1")
trash <- merge(data1, code1 , by="name1")
head(trash)

## 그래프 그리기 
ggChoropleth(trash, pusmap2,fillvar="매립처리량연간.톤.")
ggChoropleth(trash, pusmap2,fillvar="음식물류발생량연간.톤.")


##ggplot2와 ggChoropleth로 그려보기 
theme_set(theme_gray(base_family="NanumGothic"))

ggplot(trash,
aes(map_id=code,fill=재활용처리량연간.톤.))+
geom_map(map=pusmap2,colour="black",size=0.1)+
expand_limits(x=pusmap2$long,y=pusmap2$lat)+
scale_fill_gradientn(colours=c('white','orange','red') )+
ggtitle("부산 구별  재활용처리량연간")+
coord_map()


ggChoropleth(trash,pusmap2,fillvar="재활용처리량연간.톤.") +
ggtitle("부산 구별  재활용처리량연간")

